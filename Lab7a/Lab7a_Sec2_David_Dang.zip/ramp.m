function f = ramp(t)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
f = (sign(t) + 1)*0.5;
f = f.*t;
return

