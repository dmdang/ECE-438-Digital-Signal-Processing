x = [2,4,5];
sum(x)
y = x.^2
