load test
coef = myplc(x,15)
transpose(a)