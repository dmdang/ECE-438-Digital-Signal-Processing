function [x] = exciteUV(N)
%UNTITLED7 Summary of this function goes here
%   Detailed explanation goes here
x = normrnd(0,1,[1,N]);
end