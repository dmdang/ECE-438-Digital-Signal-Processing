N = 5;
A = DFTmatrix(N);
B = IDFTmatrix(N)
C = B*A