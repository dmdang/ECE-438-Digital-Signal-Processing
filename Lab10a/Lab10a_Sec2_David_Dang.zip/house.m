A = imread('house.tif');
Hist(A);